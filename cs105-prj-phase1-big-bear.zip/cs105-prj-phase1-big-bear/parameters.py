#search query

file_name = 'profiles_san_francisco.csv'

linkedin_username = 'educationalcrawler@gmail.com'
linkedin_password = 'justlearning42'


search_query = 'site:linkedin.com/in/ AND "c++ developer"'
